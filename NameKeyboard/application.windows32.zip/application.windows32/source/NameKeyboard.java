import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class NameKeyboard extends PApplet {

//Global Variable
int x, y;

public void setup() {
  size(800,800);
  frameRate(10);
  // Set start coords
  x = width/2;
  y = height/2;
}

public void draw() {
  //drawName();
  //noLoop();
}

// Method to draw right line
public void moveRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    stroke(random(255),random(255),random(255));
    point(x+i, y);
  }
  x=x+(10*rep);
}
public void moveDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    stroke(random(255),random(255),random(255));
    point(x, y+i);
  }
  y=y+(10*rep);
}
public void moveUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    stroke(random(255),random(255),random(255));
    point(x, y-i);
  }
  y=y-(10*rep);
}
public void moveRightDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(y+i, x+i);
  }

  y=y+(10*rep);
  x=x+(10*rep);
}
public void moveLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    stroke(random(255),random(255),random(255));
    point(x-i, y);
  }
  x=x-(10*rep);
}
public void keyPressed() {
  if (key == CODED) {
    if (keyCode == RIGHT) {
      moveRight(5);
    } else if(keyCode == DOWN) {
      moveDown(5);
    } else if(keyCode == UP) {
      moveUp(5);
    } else if(keyCode == LEFT) {
      moveLeft(5);
    } //else if(keyCode == RIGHT && keyCode == DOWN) {
      //rightDown(1);
    //}
  }
}

//Take Picture
public void mouseClicked() {
  
  saveFrame("line-######.png");
  
}


  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--hide-stop", "NameKeyboard" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
